#include <iostream>
#include "funciones.h"

using namespace std;

/// IMPLEMENTACION
/// ARCHIVOS .cpp

int pedirNumero(){
    int n;
    cout << "Ingrese #: ";
    cin >> n;
    return n;
}
int sumarNumeros(int n1, int n2){
    return (n1 + n2);
}
void mostrarNumero(int n){
    cout << "El numero es: " << n << endl;
}

void sumaDosNumeros(){
    int num1, num2, suma;

    num1 = pedirNumero();
    num2 = pedirNumero();

    suma = sumarNumeros(num1, num2);

    mostrarNumero(suma);

}
