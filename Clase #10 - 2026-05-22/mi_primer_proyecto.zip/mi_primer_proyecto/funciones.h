#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

/// INICIO
/// DECLARACION
/// ARCHIVOS .h

int pedirNumero();
int sumarNumeros(int n1, int n2);
void mostrarNumero(int n);

void sumaDosNumeros();


/// FIN

#endif // FUNCIONES_H_INCLUDED
