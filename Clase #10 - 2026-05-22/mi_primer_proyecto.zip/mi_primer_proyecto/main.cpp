#include <iostream>
#include "funciones.h"  /// HOJA DE FUNCIONES

using namespace std;

int main()
{
    /// LLAMADA A LA FUNCION
    sumaDosNumeros();

    return 0;
}

