#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

void menuPrincipal();
void menuOpciones();


#endif // MENU_H_INCLUDED
