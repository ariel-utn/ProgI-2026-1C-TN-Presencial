#include <iostream>
#include "jugar.h"

using namespace std;


void jugar(int &p1, int &p2)
{
    /// DECLARACION
    int const TAM = 5;
    int tiradaDados[TAM];


    cout << "JUGAR" << endl;



    for (int ronda = 1; ronda <=3; ronda++)
    {
        int puntajeRondaJugador1 = 0;
        int puntajeRondaJugador2 = 0;

        system("cls");

        cout << "RONDA #" << ronda << " JUGADOR 1" << endl;

        /// SIMULAR TIRADA DE DADOS
        simularTirada(tiradaDados,TAM);

        /// MOSTRAR TIRADA
        mostrarTirada(tiradaDados,TAM);

        /// OBTENGO LA SUMA
        puntajeRondaJugador1 = obtenerSumaVector(tiradaDados,TAM);

        /// MUESTRO PUNTAJE
        cout << "EL JUGADOR OBTUVO: " << puntajeRondaJugador1 << " puntos" << endl;

        p1+=puntajeRondaJugador1;

        /// MUESTRO PUNTAJE TOTAL
        cout << "PUNTOS TOTALES: " << p1 << " puntos" << endl;





        cout << "RONDA #" << ronda << " JUGADOR 2" << endl;

        /// SIMULAR TIRADA DE DADOS
        simularTirada(tiradaDados,TAM);

        /// MOSTRAR TIRADA
        mostrarTirada(tiradaDados,TAM);

        /// OBTENGO LA SUMA
        puntajeRondaJugador2 = obtenerSumaVector(tiradaDados,TAM);

        /// MUESTRO PUNTAJE
        cout << "EL JUGADOR OBTUVO: " << puntajeRondaJugador2 << " puntos" << endl;

        p2+=puntajeRondaJugador2;

        /// MUESTRO PUNTAJE TOTAL
        cout << "PUNTOS TOTALES: " << p2 << " puntos" << endl;

        system("pause");
    }


    if(p1>p2)
    {
        cout << "EL GANADOR FUE J1 CON " << p1 << " puntos" << endl;

    }
    else if(p2>p1)
    {
        cout << "EL GANADOR FUE J2 CON " << p2 << " puntos" << endl;
    }
    else
    {
        cout << "EMPATE!!!" << endl;
    }

     system("pause");
}

int obtenerNroAleatorio(int rango)
{
    return rand()%rango + 1;
}

void simularTirada(int v[], int tam)
{
    for(int i = 0; i < tam; i++)
    {
        v[i] = obtenerNroAleatorio(8);
    }
}

void mostrarTirada(int v[], int tam)
{
    for(int i = 0; i < tam; i++)
    {
        cout << v[i] << endl;
    }
}

int obtenerSumaVector(int v[], int tam)
{
    int acu = 0;
    for(int i = 0; i < tam; i++)
    {
        acu += v[i];
    }
    return acu;
}

