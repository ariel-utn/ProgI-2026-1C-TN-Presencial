#include <iostream>
#include <ctime>
#include "menu.h"

using namespace std;

int main()
{
    ///SEMILLA
    srand(time(nullptr));

    menuPrincipal();



//
//    /// OBTENGO LA SUMA
//    int suma;
//    suma = obtenerSumaVector(tiradaDados,TAM);
//
//    cout << "La suma es: " << suma << endl;




    return 0;
}





