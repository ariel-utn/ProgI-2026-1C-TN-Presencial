#include <iostream>
#include "estadisticas.h"

using namespace std;


void estadisticas(){

    cout << "ESTADISTICAS" << endl;
    system("pause");
}
