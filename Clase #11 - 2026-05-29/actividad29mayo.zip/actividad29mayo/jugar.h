#ifndef JUGAR_H_INCLUDED
#define JUGAR_H_INCLUDED

void jugar(int &p1, int &p2);
int obtenerNroAleatorio(int rango);
void simularTirada(int v[], int tam);
void mostrarTirada(int v[], int tam);
int obtenerSumaVector(int v[], int tam);

#endif // JUGAR_H_INCLUDED
