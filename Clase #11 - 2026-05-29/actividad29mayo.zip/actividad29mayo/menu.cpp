#include <iostream>
#include "menu.h"
#include "jugar.h"
#include "estadisticas.h"

using namespace std;

void menuPrincipal()
{


    while(true)
    {
        system("cls");
        int opcion;
        menuOpciones();
        cin >> opcion;
        switch(opcion)
        {
        case 1:
        {
            int puntaje1 = 0;
            int puntaje2 = 0;
            jugar(puntaje1,puntaje2);
        }
        break;
        case 2:
        {
            estadisticas();
        }
        break;
        case 3:
        {
            cout << " Gracias por jugar!!!!" << endl;
            system("pause");
            return;

        }
        break;
        default:
        {
            cout << "OPCION INVALIDA!";
        }
        }

    }
}

void menuOpciones()
{

    cout << "-------------" << endl;
    cout << "1 - JUGAR    " << endl;
    cout << "2 - ESTAD.   " << endl;
    cout << "3 - SALIR    " << endl;

}

